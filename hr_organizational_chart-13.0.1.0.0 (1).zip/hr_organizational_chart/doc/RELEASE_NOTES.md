## Module <hr_organizational_chart>

#### 15.03.2020
#### Version 13.0.1.0.0
##### ADD
- Initial commit
