Advanced Organizational Chart
=============================

This module used for get hierarchy of employees.

Depends
=======
[hr] addon Odoo


Installation
============
- www.odoo.com/documentation/13.0/setup/install.html
- Install our custom addon

Credits
=======
* Cybrosys Techno Solutions<https://www.cybrosys.com>

Author
------

Developers: v13.0 YADHU K <odoo@cybrosys.com>

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.

